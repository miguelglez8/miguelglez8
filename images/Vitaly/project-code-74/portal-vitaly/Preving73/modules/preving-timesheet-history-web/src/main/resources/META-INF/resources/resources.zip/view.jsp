<%@ include file="/init.jsp" %>

<script>

    var p_auth = "?p_auth=" + Liferay.authToken;

    var activities = '${activities}';
    var holidays = '${holidays}';
    var signs    = '${signs}';

    console.log(activities);
    console.log(holidays);
    console.log(signs);

    var xhrURL_Actividades = {
        actividades: activities,
        festivos: holidays,
        fichajes: signs
    };


    $(document).ready(function(){
        //iniciar el calendario
        var ID_USUARIO = "ID_USUARIO";
        CalendarioBarras.initCalendarioBarras(xhrURL_Actividades,ID_USUARIO, null, null);

        var dS = new Date();

        dS.setTime(1594306800000);
        var dE = new Date();
        dE.setTime(1594317600000);
        console.log(dS.getTimezoneOffset())
        console.log("start: " + dS.toString());
        console.log("end : " + dE.toString());

    });


</script>

<div style="margin-left:1%;width: 98%;">
    <div id="ccCalendario"></div>
    <div style="float:left;width:45%;">
        <button onclick="CalendarioBarras.moveMonth(-1)" type="button">&lt;</button>
        &nbsp;&nbsp;<span id="spanMesActual" style="width:150px;display:inline-table;text-align:center;">MES</span>&nbsp;&nbsp;
        <button onclick="CalendarioBarras.moveMonth(+1)" type="button">&gt;</button>
    </div>
    <div style="float:right;width:55%;text-align: right;">
        Fecha desde&nbsp;<input id="inpFechaDesde" type="date">
        &nbsp;hasta&nbsp;<input id="inpFechaHasta" type="date">
        &nbsp;&nbsp;&nbsp;<button onClick="CalendarioBarras.filterFechas()" type="button">Buscar</button>
    </div>
    <div id="capaLeyenda"></div>
    <div id="contenedorCalendario" style="height: 70vh; overflow-x: hidden; overflow-y:auto;">
        <div id="capaHorario" ></div>
        <div class="row border">
            <div class="col-9"></div>
            <div class="col-1 right"><b>TOTAL</b></div>
            <div class="col-2"><b><span id="spanTotalHoras"></span>&nbsp;horas</b></div>
        </div>
    </div>
    <div id="capaDetalles"></div>
</div>